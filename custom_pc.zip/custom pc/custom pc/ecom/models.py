from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Customer(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    profile_pic= models.ImageField(upload_to='profile_pic/CustomerProfilePic/',null=True,blank=True)
    address = models.CharField(max_length=40)
    mobile = models.CharField(max_length=20,null=False)
    @property
    def get_name(self):
        return self.user.first_name+" "+self.user.last_name
    @property
    def get_id(self):
        return self.user.id
    def __str__(self):
        return self.user.first_name


class Product(models.Model):
    name=models.CharField(max_length=40)
    product_image= models.ImageField(upload_to='product_image/',null=True,blank=True)
    price = models.PositiveIntegerField()
    description=models.CharField(max_length=40)
    category=[
        ('chair', 'gaming'),
        ('sofa', 'workstation'),
        ('mirror', 'Laptops'),
        ('beanbag', 'Home/office'),
        ('table', 'Tablets'),
        ('bed', 'minicomputer'),
    ]

    category = models.CharField(max_length=40, null=True, choices=category)
    
    def __str__(self):
        return self.name


class Product_chair(models.Model):
    name=models.CharField(max_length=40)
    product_image= models.ImageField(upload_to='product_image/',null=True,blank=True)
    price = models.PositiveIntegerField()
    description=models.CharField(max_length=40)
    def __str__(self):
        return self.name

class Orders(models.Model):
    STATUS =(
        ('Pending','Pending'),
        ('Order Confirmed','Order Confirmed'),
        ('Out for Delivery','Out for Delivery'),
        ('Delivered','Delivered'),
    )
    customer=models.ForeignKey('Customer', on_delete=models.CASCADE,null=True)
    product=models.ForeignKey('Product',on_delete=models.CASCADE,null=True)
    email = models.CharField(max_length=50,null=True)
    address = models.CharField(max_length=500,null=True)
    mobile = models.CharField(max_length=20,null=True)
    order_date= models.DateField(auto_now_add=True,null=True)
    status=models.CharField(max_length=50,null=True,choices=STATUS)


class Feedback(models.Model):
    name=models.CharField(max_length=40)
    feedback=models.CharField(max_length=500)
    date= models.DateField(auto_now_add=True,null=True)
    def __str__(self):
        return self.name
    


class Customize(models.Model):
    customer=models.ForeignKey('Customer', on_delete=models.CASCADE,null=True)
    name = models.CharField(max_length=100,null=True)
    details = models.TextField(max_length=500,null=True)
    STATUS_CHOICES = (
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected'),
        ('Paid','Paid'),
    )
    status = models.CharField(max_length=20,null=True,choices=STATUS_CHOICES)
    carpenter = models.CharField(max_length=100, null=True)
    date = models.DateField(null=True)  
    price = models.CharField(max_length=10, null=True)
    phone = models.CharField(max_length=15, null=True)
    def __str__(self):
        return self.name


class Carpenter(models.Model):
    username = models.CharField(max_length=100, unique=True)
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    address = models.TextField()
    def __str__(self):
        return self.username
    
# from django.contrib.auth import logout
# from django.shortcuts import redirect

# def logout_view(request):
#     logout(request)
#     return redirect('home')  # Redirect to the home page or any other desired URL after logout
# from django.urls import path
# from . import views

# urlpatterns = [
#     # Other URL patterns in your project
#     path('logout/', views.logout_view, name='logout'),
# ]
# <!-- Example logout link -->
# <a href="{% url 'logout' %}">Logout</a>



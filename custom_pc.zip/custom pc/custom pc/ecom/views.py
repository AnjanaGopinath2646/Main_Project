from django.shortcuts import render,redirect,reverse, get_object_or_404
from . import forms,models
from django.http import HttpResponseRedirect,HttpResponse
from django.core.mail import send_mail
from django.contrib.auth.models import Group
# from django.contrib.auth import logout

from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required,user_passes_test
from django.contrib import messages
from django.conf import settings




from .forms import CustomizeForm

# def customize_form(request):
#     if request.method == 'POST':
#         form = CustomizeForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect('customer-home')
#     else:
#         form = CustomizeForm()
#     return render(request, 'customize.html', {'form': form})
def customize_form(request):
    if request.method == 'POST':
        form = CustomizeForm(request.POST)
        if form.is_valid():
            # Retrieve the Customer instance associated with the current user
            customer_instance = Customer.objects.get(user=request.user)
            
            # Save the form with the retrieved Customer instance
            customize_instance = form.save(commit=False)
            customize_instance.customer = customer_instance
            customize_instance.status = 'Pending'  # Set status as Pending
            customize_instance.save()
            return redirect('customer-home')
    else:
        form = CustomizeForm()
    return render(request, 'customize.html', {'form': form})

def home_view(request):
    products=models.Product.objects.all()
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter=product_ids.split('|')
        product_count_in_cart=len(set(counter))
    else:
        product_count_in_cart=0
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    user = request.user
    return render(request,'ecom/index.html',{'products':products,'product_count_in_cart':product_count_in_cart,'user':user})
    


# def prduct_chair(request):
#     products=models.Product_chair.objects.all()
#     if 'product_ids' in request.COOKIES:
#         product_ids = request.COOKIES['product_ids']
#         counter=product_ids.split('|')
#         product_count_in_cart=len(set(counter))
#     else:
#         product_count_in_cart=0
#     user = request.user
#     return render(request,'ecom/prduct_chair.html',{'products':products,'product_count_in_cart':product_count_in_cart,'user':user})


def prduct_chair(request):
    products=models.Product.objects.all()
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter=product_ids.split('|')
        product_count_in_cart=len(set(counter))
    else:
        product_count_in_cart=0
    user = request.user
    return render(request,'ecom/prduct_chair.html',{'products':products,'product_count_in_cart':product_count_in_cart,'user':user})
    
   


def prduct_table(request):
    products=models.Product.objects.all()
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter=product_ids.split('|')
        product_count_in_cart=len(set(counter))
    else:
        product_count_in_cart=0
    user = request.user
    return render(request,'ecom/prduct_table.html',{'products':products,'product_count_in_cart':product_count_in_cart,'user':user})
    
   


def prduct_sofa(request):
    products=models.Product.objects.all()
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter=product_ids.split('|')
        product_count_in_cart=len(set(counter))
    else:
        product_count_in_cart=0
    user = request.user
    return render(request,'ecom/prduct_sofa.html',{'products':products,'product_count_in_cart':product_count_in_cart,'user':user})
    
   


def prduct_bed(request):
    products=models.Product.objects.all()
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter=product_ids.split('|')
        product_count_in_cart=len(set(counter))
    else:
        product_count_in_cart=0
    user = request.user
    return render(request,'ecom/prduct_bed.html',{'products':products,'product_count_in_cart':product_count_in_cart,'user':user})
    
   


def prduct_mirror(request):
    products=models.Product.objects.all()
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter=product_ids.split('|')
        product_count_in_cart=len(set(counter))
    else:
        product_count_in_cart=0
    user = request.user
    return render(request,'ecom/prduct_mirror.html',{'products':products,'product_count_in_cart':product_count_in_cart,'user':user})
    
   


def prduct_beanbag(request):
    products=models.Product.objects.all()
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter=product_ids.split('|')
        product_count_in_cart=len(set(counter))
    else:
        product_count_in_cart=0
    user = request.user
    return render(request,'ecom/prduct_beanbag.html',{'products':products,'product_count_in_cart':product_count_in_cart,'user':user})
    

#for showing login button for admin(by sumit)
def adminclick_view(request):
    logout(request)
    if request.user.is_authenticated:
        return HttpResponseRedirect('afterlogin')
    return HttpResponseRedirect('adminlogin')

from django.contrib.auth import login, authenticate
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm 
from .forms import CustomerForm  
from .models import Customer

# def customer_signup_view(request):
#     logout(request)
#     if request.method == 'POST':
#         if request.user.is_authenticated:
#             logout(request)
#         username = request.POST['username']
#         first_name = request.POST['first_name']
#         last_name = request.POST['last_name']
#         password1 = request.POST['password1']
#         password2 = request.POST['password2']
#         address = request.POST['address']
#         mobile = request.POST['mobile']
#         profile_pic = request.FILES.get('profile_pic')  # Use .get() for optional

#         # Optional validation (consider using UserCreationForm for security)
#         if password1 != password2:
#             # Handle password mismatch error
#             return render(request, 'ecom/customersignup.html', {'error': 'Passwords do not match!'})
#         if User.objects.filter(username__iexact=username).exists():
#             return render(request, 'ecom/customersignup.html', {'error': 'Username already exists!'})
        
#         user = User.objects.create_user(username=username, password=password1, first_name=first_name, last_name=last_name)
#         customer = Customer(user=user, address=address, mobile=mobile, profile_pic=profile_pic)
#         customer.save()
#         if request.user.is_authenticated:
#             logout(request)
#         return redirect('customerlogin')
#     else:
#         context = {} 
#     return render(request, 'ecom/customersignup.html', context)
def customer_signup_view(request):
    userForm=forms.CustomerUserForm()
    customerForm=forms.CustomerForm()
    mydict={'userForm':userForm,'customerForm':customerForm}
    if request.method=='POST':
        userForm=forms.CustomerUserForm(request.POST)
        customerForm=forms.CustomerForm(request.POST,request.FILES)
        print('userForm',userForm.is_valid())
        print('customerForm',customerForm.is_valid())
        if userForm.is_valid() and customerForm.is_valid():
            print('its Valid')
            user=userForm.save()
            print('user.password',user.password)
            user.set_password(user.password)
            user.save()
            customer=customerForm.save(commit=False)
            customer.user=user
            customer.save()
            my_customer_group = Group.objects.get_or_create(name='CUSTOMER')
            my_customer_group[0].user_set.add(user)
        else:
            print('Not Valid')
        return HttpResponseRedirect('customerlogin')
    return render(request,'ecom/customersignup.html',context=mydict)

#-----------for checking user iscustomer
def is_customer(user):
    return user.groups.filter(name='CUSTOMER').exists()


from .models import Carpenter
def Carpentersignup(request):
    logout(request)
    errors = {}
    if request.method == 'POST':
        username = request.POST.get('username')
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        address = request.POST.get('address')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        
        if password != confirm_password:
            errors['password_mismatch'] = "Passwords don't match"
        else:
            # Check if username is already taken
            if User.objects.filter(username=username).exists():
                errors['username_taken'] = "Username is already taken"
            else:
                # Create user object
                user = User.objects.create_user(username=username, password=password)
                user.first_name = name
                user.save()
                
                # Save additional details to Manager model
                manager = Carpenter.objects.create(username=username, name=name, phone=phone, address=address)
                
                success_message = "Registration Successful"
                return render(request, 'ecom/Carpentersignup.html', {'success_message': success_message})

    # return render(request, 'accounts/managersign.html', {'errors': errors})
    return render (request,'ecom/Carpentersignup.html', {'errors': errors})

from django.contrib.auth import authenticate, login
def Carpenterlogin(request):
    logout(request)
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            
            return redirect('Carpenterhome')  
        else:
            error = "Invalid username or password"
            return render(request, 'ecom/Carpenterlogin.html', {'error': error})
    # return render(request, 'accounts/managerlogin.html')
    return render(request,'ecom/Carpenterlogin.html')



def delete_details(request, item_id):
    
    customize_instance = get_object_or_404(Customize, pk=item_id)
    
    customize_instance.delete()
    
    return redirect('custom-view')

def Carpenterhome(request):
    return render(request,'ecom/CarpenterHome1.html')

def payment_view(request, item_id):
    if request.method == 'GET':
        item = Customize.objects.get(pk=item_id)
        price=item.price
        # item.status = 'Paid'
        price=str(price)+'(paid)'
        item.price=price
        item.save()
        # return redirect('custom-view') 
    if request.method == 'POST':
        item = Customize.objects.get(pk=item_id)
        # item.status = 'Paid'
        # item.save()
        return render(request,'ecom/Cpay.html',{'context':item,'id':item_id})
        # return redirect('Cpay')
    
    return redirect('custom-view') 



from .models import Customize
def requests(request):
    # current_user = request.user
    # print('current_user',current_user)
    # custom = custom_pending.filter(customer__user__username=current_user)
    custom = Customize.objects.filter(status='Pending')
    return render(request, 'ecom/requests.html', {'custom': custom})

# def Cprofile(request):

#     return render(request,'ecom/Cprofile.html')

from django.shortcuts import render, redirect
from .models import Carpenter
from django.contrib.auth.decorators import login_required

# @login_required
def Cprofile(request):
    current_user = request.user
    try:
        carpenter = Carpenter.objects.get(username=current_user.username)
    except Carpenter.DoesNotExist:
        # Handle the case where the Carpenter object doesn't exist
        # Maybe redirect to a page to create the profile
        return redirect('Cprofile')  # Assuming you have a URL named 'create_profile'

    if request.method == 'POST':
        # Extract updated information from the request
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        address = request.POST.get('address')

        # Update Carpenter object with the new information
        carpenter.name = name
        carpenter.phone = phone
        carpenter.address = address
        carpenter.save()

        # Redirect to a success page or wherever needed
        return redirect('Cprofile')  # Redirect to a success page, change 'profile_success' to your desired URL name

    return render(request, 'ecom/Cprofile.html', {'carpenter': carpenter})


def acceptedrequests(request):
    if request.method == 'POST':
        customize_id = request.POST.get('customize_id')
        amount = request.POST.get('amount')
        date = request.POST.get('date')
        
        customize = Customize.objects.get(pk=customize_id)
        customize.price = amount
        customize.date = date
        try:
            carpenter = Carpenter.objects.get(username=customize.carpenter)
            customize.phone = carpenter.phone
        except Carpenter.DoesNotExist:
            
            pass
        customize.save()
        messages.success(request, 'Amount and date saved successfully.')

        return redirect('acceptedrequests')

    else:
        print('request.user.username,',request.user)
        custom = Customize.objects.filter(carpenter=request.user, status='Approved')
        print('custom',custom)
        return render(request, 'ecom/acceptedrequests.html', {'custom': custom})
    
    # custom = Customize.objects.filter(carpenter=request.user.username, status='Approved')
    # return render(request,'ecom/acceptedrequests.html', {'custom': custom})


#------Carpent Request-------------#
def approve_request(request, item_id):
    customize_request = get_object_or_404(Customize, pk=item_id)
    
    customize_request.status = 'Approved'
    customize_request.carpenter = request.user.username 
    customize_request.save()
    return redirect('requests')
    # print('approved',item_id)
    # custom = Customize.objects.filter(status='Pending')
    # return render(request, 'ecom/requests.html', {'custom': custom})


def reject_request(request, item_id):
    customize_request = get_object_or_404(Customize, pk=item_id)
    customize_request.status = 'Rejected'
    customize_request.save()
    return redirect('requests')

#---------AFTER ENTERING CREDENTIALS WE CHECK WHETHER USERNAME AND PASSWORD IS OF ADMIN,CUSTOMER
def afterlogin_view(request):
    if is_customer(request.user):
        return redirect('customer-home')
    else:
        return redirect('admin-dashboard')

#---------------------------------------------------------------------------------
#------------------------ ADMIN RELATED VIEWS START ------------------------------
#---------------------------------------------------------------------------------
@login_required(login_url='adminlogin')
def admin_dashboard_view(request):
    # for cards on dashboard
    customercount=models.Customer.objects.all().count()
    productcount=models.Product.objects.all().count()
    ordercount=models.Orders.objects.all().count()

    # for recent order tables
    orders=models.Orders.objects.all()
    ordered_products=[]
    ordered_bys=[]
    for order in orders:
        ordered_product=models.Product.objects.all().filter(id=order.product.id)
        ordered_by=models.Customer.objects.all().filter(id = order.customer.id)
        ordered_products.append(ordered_product)
        ordered_bys.append(ordered_by)

    mydict={
    'customercount':customercount,
    'productcount':productcount,
    'ordercount':ordercount,
    'data':zip(ordered_products,ordered_bys,orders),
    }
    return render(request,'ecom/admin_dashboard.html',context=mydict)


# admin view customer table
@login_required(login_url='adminlogin')
def view_customer_view(request):
    customers=models.Customer.objects.all()
    return render(request,'ecom/view_customer.html',{'customers':customers})

# admin delete customer
@login_required(login_url='adminlogin')
def delete_customer_view(request,pk):
    customer=models.Customer.objects.get(id=pk)
    user=models.User.objects.get(id=customer.user_id)
    user.delete()
    customer.delete()
    return redirect('view-customer')
# def logoutuser(request):
#     logout(request)
#     return redirect('index')
@login_required
# def logoutUser(request):
#     logout(request)
#     return redirect('index.html')



def LogoutView(request):
        logout(request)

        return redirect('http://127.0.0.1:8000/')


@login_required(login_url='adminlogin')
def update_customer_view(request,pk):
    customer=models.Customer.objects.get(id=pk)
    user=models.User.objects.get(id=customer.user_id)
    userForm=forms.CustomerUserForm(instance=user)
    customerForm=forms.CustomerForm(request.FILES,instance=customer)
    mydict={'userForm':userForm,'customerForm':customerForm}
    if request.method=='POST':
        userForm=forms.CustomerUserForm(request.POST,instance=user)
        customerForm=forms.CustomerForm(request.POST,instance=customer)
        if userForm.is_valid() and customerForm.is_valid():
            user=userForm.save()
            user.set_password(user.password)
            user.save()
            customerForm.save()
            return redirect('view-customer')
    return render(request,'ecom/admin_update_customer.html',context=mydict)

# admin view the product
@login_required(login_url='adminlogin')
def admin_products_view(request):
    products=models.Product.objects.all()
    return render(request,'ecom/admin_products.html',{'products':products})




@login_required(login_url='adminlogin')
def admin_add_product_view(request):
    productForm=forms.ProductForm()
    if request.method=='POST':
        productForm=forms.ProductForm(request.POST, request.FILES)
        if productForm.is_valid():
            productForm.save()
        return HttpResponseRedirect('admin-products')
    return render(request,'ecom/admin_add_products.html',{'productForm':productForm})


@login_required(login_url='adminlogin')
def delete_product_view(request,pk):
    product=models.Product.objects.get(id=pk)
    product.delete()
    return redirect('admin-products')


@login_required(login_url='adminlogin')
def update_product_view(request,pk):
    product=models.Product.objects.get(id=pk)
    productForm=forms.ProductForm(instance=product)
    if request.method=='POST':
        productForm=forms.ProductForm(request.POST,request.FILES,instance=product)
        if productForm.is_valid():
            productForm.save()
            return redirect('admin-products')
    return render(request,'ecom/admin_update_product.html',{'productForm':productForm})


@login_required(login_url='adminlogin')
def admin_view_booking_view(request):
    orders=models.Orders.objects.all()
    ordered_products=[]
    ordered_bys=[]
    for order in orders:
        ordered_product=models.Product.objects.all().filter(id=order.product.id)
        ordered_by=models.Customer.objects.all().filter(id = order.customer.id)
        ordered_products.append(ordered_product)
        ordered_bys.append(ordered_by)
    return render(request,'ecom/admin_view_booking.html',{'data':zip(ordered_products,ordered_bys,orders)})

def admin_custom(request):
    # custom_orders=models.Customize.objects.all()
    # custom_orders=[]
    # ordered_by=[]
    # for custom in custom_orders:
    #     # ordered_product=models.Product.objects.all().filter(id=order.product.id)
    #     ordered_by=models.Customer.objects.all().filter(id = custom.customer.id)
    #     custom_orders.append(ordered_product)
    #     ordered_by.append(ordered_by)
    # return render(request,'ecom/admin_custom.html',{'data':zip(custom_orders,ordered_by,custom_orders)})
    custom=models.Customize.objects.all()
    return render(request,'ecom/admin_custom.html',{'custom':custom})
# admin add product by clicking on floating button
@login_required(login_url='adminlogin')
def delete_order_view(request,pk):
    order=models.Orders.objects.get(id=pk)
    order.delete()
    return redirect('admin-view-booking')

# for changing status of order (pending,delivered...)
@login_required(login_url='adminlogin')
def update_order_view(request,pk):
    order=models.Orders.objects.get(id=pk)
    orderForm=forms.OrderForm(instance=order)
    if request.method=='POST':
        orderForm=forms.OrderForm(request.POST,instance=order)
        if orderForm.is_valid():
            orderForm.save()
            return redirect('admin-view-booking')
    return render(request,'ecom/update_order.html',{'orderForm':orderForm})
# customize
def custom_update_order(request,pk):
    custom_order=models.Customize.objects.get(id=pk)
    orderForm=forms.CustamizeForm(instance=custom_order)
    if request.method=='POST':
        orderForm=forms.CustamizeForm(request.POST,instance=custom_order)
        if orderForm.is_valid():
            orderForm.save()
            return redirect('admin-custom')
    return render(request,'ecom/custom_updateorder.html',{'orderForm':orderForm})


# admin view the feedback
@login_required(login_url='adminlogin')
def view_feedback_view(request):
    feedbacks=models.Feedback.objects.all().order_by('-id')
    return render(request,'ecom/view_feedback.html',{'feedbacks':feedbacks})



#---------------------------------------------------------------------------------
#------------------------ PUBLIC CUSTOMER RELATED VIEWS START ---------------------
#---------------------------------------------------------------------------------
def search_view(request):
    # whatever user write in search box we get in query
    query = request.GET['query']
    products=models.Product.objects.all().filter(name__icontains=query)
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter=product_ids.split('|')
        product_count_in_cart=len(set(counter))
    else:
        product_count_in_cart=0

    # word variable will be shown in html when user click on search button
    word="Searched Result :"

    if request.user.is_authenticated:
        return render(request,'ecom/customer_home.html',{'products':products,'word':word,'product_count_in_cart':product_count_in_cart})
    return render(request,'ecom/index.html',{'products':products,'word':word,'product_count_in_cart':product_count_in_cart})


# any one can add product to cart, no need of signin
def add_to_cart_view(request,pk):
    products=models.Product.objects.all()
    # print('1')
    #for cart counter, fetching products ids added by customer from cookies
    if 'product_ids' in request.COOKIES:
        # print('2')
        product_ids = request.COOKIES['product_ids']
        # print('3',product_ids,type(product_ids))
        # product_ids='5|5|5|4|5|5|7|6|6|5|4|5|4|3|3|3|3'
        counter=product_ids.split('|')
        # counter[0]=3
        # print('4',counter,type(counter))
        product_count_in_cart=len(set(counter))
        # print('5')
    else:
        # print('6')
        product_count_in_cart=1
        # print('7')

    response = render(request, 'ecom/customer_home.html',{'products':products,'product_count_in_cart':product_count_in_cart})

    #adding product id to cookies
    if 'product_ids' in request.COOKIES:
        # print('8',product_ids)

        product_ids = request.COOKIES['product_ids']
        # print('9',product_ids)
        if product_ids=="":
            # print('10',product_ids)
            product_ids=str(pk)
            # print('11',product_ids)
        else:
            print(type(product_ids))
            # print('12',product_ids)
            product_ids=product_ids+"|"+str(pk)
            # print('13',product_ids)
        # product_ids='5|5|5|4|5|5|7|6|6|5|4|5|4|3|3|3|3'
        response.set_cookie('product_ids', product_ids)
        # print('14',product_ids)
    else:
        # print('15')
        response.set_cookie('product_ids', pk)
        # print('16',product_ids)

    product=models.Product.objects.get(id=pk)
    messages.info(request, product.name + ' added to cart successfully!')

    return response


# def add_to_cart_view_1(request,pk):
#     products=models.Product.objects.all()

#     #for cart counter, fetching products ids added by customer from cookies
#     if 'product_ids' in request.COOKIES:
#         product_ids = request.COOKIES['product_ids']
#         counter=product_ids.split('|')
#         product_count_in_cart=len(set(counter))
#     else:
#         product_count_in_cart=1

#     response = render(request, 'ecom/index.html',{'products':products,'product_count_in_cart':product_count_in_cart})

#     #adding product id to cookies
#     if 'product_ids' in request.COOKIES:
#         product_ids = request.COOKIES['product_ids']
#         if product_ids=="":
#             product_ids=str(pk)
#         else:
#             product_ids=product_ids+"|"+str(pk)
#         response.set_cookie('product_ids', product_ids)
#     else:
#         response.set_cookie('product_ids', pk)

#     product=models.Product.objects.get(id=pk)
#     messages.info(request, product.name + ' added to cart successfully!')

    # return response


# for checkout of cart
def cart_view(request):
    #for cart counter
    # print('1')
    if 'product_ids' in request.COOKIES:
        # print('2')
        product_ids = request.COOKIES['product_ids']
        # print('3')
        # print(product_ids)
        counter=product_ids.split('|')
        # print('4')
        # print(counter)
        product_count_in_cart=len(set(counter))
        # print('5')
        # print(product_count_in_cart)
    else:
        # print('6')
        product_count_in_cart=0

    # fetching product details from db whose id is present in cookie
    products=None
    total=0
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        if product_ids != "":
            product_id_in_cart=product_ids.split('|')
            products=models.Product.objects.all().filter(id__in = product_id_in_cart)

            #for total price shown in cart
            for p in products:
                total=total+p.price
    return render(request,'ecom/cart.html',{'products':products,'total':total,'product_count_in_cart':product_count_in_cart})


def remove_from_cart_view(request,pk):
    #for counter in cart
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter=product_ids.split('|')
        product_count_in_cart=len(set(counter))
    else:
        product_count_in_cart=0

    # removing product id from cookie
    total=0
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        product_id_in_cart=product_ids.split('|')
        product_id_in_cart=list(set(product_id_in_cart))
        product_id_in_cart.remove(str(pk))
        products=models.Product.objects.all().filter(id__in = product_id_in_cart)
        #for total price shown in cart after removing product
        for p in products:
            total=total+p.price

        #  for update coookie value after removing product id in cart
        value=""
        for i in range(len(product_id_in_cart)):
            if i==0:
                value=value+product_id_in_cart[0]
            else:
                value=value+"|"+product_id_in_cart[i]
        response = render(request, 'ecom/cart.html',{'products':products,'total':total,'product_count_in_cart':product_count_in_cart})
        if value=="":
            response.delete_cookie('product_ids')
        response.set_cookie('product_ids',value)
        return response


def send_feedback_view(request):
    feedbackForm=forms.FeedbackForm()
    if request.method == 'POST':
        feedbackForm = forms.FeedbackForm(request.POST)
        if feedbackForm.is_valid():
            feedbackForm.save()
            return render(request, 'ecom/feedback_sent.html')
    return render(request, 'ecom/send_feedback.html', {'feedbackForm':feedbackForm})


#---------------------------------------------------------------------------------
#------------------------ CUSTOMER RELATED VIEWS START ------------------------------
#---------------------------------------------------------------------------------
@login_required(login_url='customerlogin')
@user_passes_test(is_customer)
def customer_home_view(request):
    products=models.Product.objects.all()
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter=product_ids.split('|')
        product_count_in_cart=len(set(counter))
    else:
        product_count_in_cart=0
    return render(request,'ecom/customer_home.html',{'products':products,'product_count_in_cart':product_count_in_cart})



# shipment address before placing order
@login_required(login_url='customerlogin')
def customer_address_view(request):
    
    product_in_cart=False
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        if product_ids != "":
            product_in_cart=True
    #for counter in cart
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        counter=product_ids.split('|')
        product_count_in_cart=len(set(counter))
    else:
        product_count_in_cart=0

    addressForm = forms.AddressForm()
    if request.method == 'POST':
        addressForm = forms.AddressForm(request.POST)
        if addressForm.is_valid():
            # here we are taking address, email, mobile at time of order placement
            # we are not taking it from customer account table because
            # these thing can be changes
            email = addressForm.cleaned_data['Email']
            mobile=addressForm.cleaned_data['Mobile']
            address = addressForm.cleaned_data['Address']
            #for showing total price on payment page.....accessing id from cookies then fetching  price of product from db
            total=0
            if 'product_ids' in request.COOKIES:
                product_ids = request.COOKIES['product_ids']
                if product_ids != "":
                    product_id_in_cart=product_ids.split('|')
                    products=models.Product.objects.all().filter(id__in = product_id_in_cart)
                    for p in products:
                        total=total+p.price

            response = render(request, 'ecom/payment.html',{'total':total})
            response.set_cookie('email',email)
            response.set_cookie('mobile',mobile)
            response.set_cookie('address',address)
            return response
    return render(request,'ecom/customer_address.html',{'addressForm':addressForm,'product_in_cart':product_in_cart,'product_count_in_cart':product_count_in_cart})




# here we are just directing to this view...actually we have to check whther payment is successful or not
#then only this view should be accessed
@login_required(login_url='customerlogin')
def payment_success_view(request):
    # Fetch customer details
    try:
        customer = models.Customer.objects.get(user=request.user)
    except models.Customer.DoesNotExist:
        # Handle the case where the customer does not exist
        return HttpResponseRedirect(reverse('customerlogin'))  # Redirect to login page

    # Initialize variables
    products = None
    email = None
    mobile = None
    address = None

    # Fetch product details from cookies
    if 'product_ids' in request.COOKIES:
        product_ids = request.COOKIES['product_ids']
        if product_ids:
            product_id_list = product_ids.split('|')
            products = models.Product.objects.filter(id__in=product_id_list)

    # Fetch customer details from cookies
    email = request.COOKIES.get('email', None)
    mobile = request.COOKIES.get('mobile', None)
    address = request.COOKIES.get('address', None)

    # Place orders
    if products:
        for product in products:
            models.Orders.objects.create(
                customer=customer,
                product=product,
                status='Pending',
                email=email,
                mobile=mobile,
                address=address
            )

    # Clear cookies after placing orders
    response = render(request, 'ecom/payment_success.html')
    response.delete_cookie('product_ids')
    response.delete_cookie('email')
    response.delete_cookie('mobile')
    response.delete_cookie('address')
    return response





@login_required(login_url='customerlogin')
@user_passes_test(is_customer)
def my_order_view(request):
    
    customer=models.Customer.objects.get(user_id=request.user.id)
    orders=models.Orders.objects.all().filter(customer_id = customer)
    ordered_products=[]
    for order in orders:
        ordered_product=models.Product.objects.all().filter(id=order.product.id)
        ordered_products.append(ordered_product)

    return render(request,'ecom/my_order.html',{'data':zip(ordered_products,orders)})
# custom
from .models import Customize, Carpenter

def custom_view(request):
    current_user = request.user
    custom_orders = Customize.objects.filter(customer__user=current_user)
    
    carpenter_phone_numbers = {}
    custom = []
    for order in custom_orders:
        if order.carpenter:  # Check if the order has a carpenter assigned
            carpenter_name = order.carpenter
            try:
                carpenter = Carpenter.objects.get(username=carpenter_name)
                carpenter_phone_numbers[carpenter_name] = carpenter.phone
            except Carpenter.DoesNotExist:
                # Handle case where carpenter does not exist or phone number is not available
                pass
        custom.append(order)

    return render(request, 'ecom/custom_order_view.html', {'custom': custom, 'carpenter_phone_numbers': carpenter_phone_numbers})

# def custom_view(request):
#     current_user = request.user
#     print('current_user',current_user)
#     # custom = Customize.objects.filter(customer=current_user)
#     custom=models.Customize.objects.all()
#     current_user = request.user
#     print('current_user',current_user)
#     custom = custom.filter(customer__user__username=current_user)
#     return render(request,'ecom/custom_order_view.html',{'custom':custom})
    
#     # customer=models.Customer.objects.get(user_id=request.user.id)
#     custom=models.Customize.objects.all()
#     ordered_products=[]
#     for order in custom:
#         # ordered_product=models.Product.objects.all().filter(id=order.product.id)
#         ordered_products.append(custom)

#     return render(request,'ecom/custom_order_view.html') 



# @login_required(login_url='customerlogin')
# @user_passes_test(is_customer)
# def my_order_view2(request):

#     products=models.Product.objects.all()
#     if 'product_ids' in request.COOKIES:
#         product_ids = request.COOKIES['product_ids']
#         counter=product_ids.split('|')
#         product_count_in_cart=len(set(counter))
#     else:
#         product_count_in_cart=0
#     return render(request,'ecom/my_order.html',{'products':products,'product_count_in_cart':product_count_in_cart})    



#--------------for discharge patient bill (pdf) download and printing
import io
from xhtml2pdf import pisa
from django.template.loader import get_template
from django.template import Context
from django.http import HttpResponse


def render_to_pdf(template_src, context_dict):
    template = get_template(template_src)
    html  = template.render(context_dict)
    result = io.BytesIO()
    pdf = pisa.pisaDocument(io.BytesIO(html.encode("ISO-8859-1")), result)
    if not pdf.err:
        return HttpResponse(result.getvalue(), content_type='application/pdf')
    return

@login_required(login_url='customerlogin')
@user_passes_test(is_customer)
def download_invoice_view(request,orderID,productID):
    order=models.Orders.objects.get(id=orderID)
    product=models.Product.objects.get(id=productID)
    mydict={
        'orderDate':order.order_date,
        'customerName':request.user,
        'customerEmail':order.email,
        'customerMobile':order.mobile,
        'shipmentAddress':order.address,
        'orderStatus':order.status,

        'productName':product.name,
        'productImage':product.product_image,
        'productPrice':product.price,
        'productDescription':product.description,


    }
    return render_to_pdf('ecom/download_invoice.html',mydict)





@login_required(login_url='customerlogin')
@user_passes_test(is_customer)
def my_profile_view(request):
    customer=models.Customer.objects.get(user_id=request.user.id)
    return render(request,'ecom/my_profile.html',{'customer':customer})


@login_required(login_url='customerlogin')
@user_passes_test(is_customer)
def edit_profile_view(request):
    customer=models.Customer.objects.get(user_id=request.user.id)
    user=models.User.objects.get(id=customer.user_id)
    userForm=forms.CustomerUserForm(instance=user)
    customerForm=forms.CustomerForm(request.FILES,instance=customer)
    mydict={'userForm':userForm,'customerForm':customerForm}
    if request.method=='POST':
        userForm=forms.CustomerUserForm(request.POST,instance=user)
        customerForm=forms.CustomerForm(request.POST,instance=customer)
        if userForm.is_valid() and customerForm.is_valid():
            user=userForm.save()
            user.set_password(user.password)
            user.save()
            customerForm.save()
            return HttpResponseRedirect('my-profile')
    return render(request,'ecom/edit_profile.html',context=mydict)



#---------------------------------------------------------------------------------
#------------------------ ABOUT US AND CONTACT US VIEWS START --------------------
#---------------------------------------------------------------------------------
def aboutus_view(request):
    logout(request)
    return render(request,'ecom/aboutus.html')

def contactus_view(request):
    sub = forms.ContactusForm()
    if request.method == 'POST':
        sub = forms.ContactusForm(request.POST)
        if sub.is_valid():
            email = sub.cleaned_data['Email']
            name=sub.cleaned_data['Name']
            message = sub.cleaned_data['Message']
            send_mail(str(name)+' || '+str(email),message, settings.EMAIL_HOST_USER, settings.EMAIL_RECEIVING_USER, fail_silently = False)
            return render(request, 'ecom/contactussuccess.html')
    return render(request, 'ecom/contactus.html', {'form':sub})

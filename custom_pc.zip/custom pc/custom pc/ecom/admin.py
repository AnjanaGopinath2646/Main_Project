from django.contrib import admin
from .models import Customer,Product,Product_chair,Orders,Feedback,Customize,Carpenter
# Register your models here.
class CustomerAdmin(admin.ModelAdmin):
    pass
admin.site.register(Customer, CustomerAdmin)

class ProductAdmin(admin.ModelAdmin):
    pass
admin.site.register(Product, ProductAdmin)
admin.site.register(Product_chair)
admin.site.register(Carpenter)

class OrderAdmin(admin.ModelAdmin):
    pass
admin.site.register(Orders, OrderAdmin)

class FeedbackAdmin(admin.ModelAdmin):
    pass
admin.site.register(Feedback, FeedbackAdmin)

# class CustomAdmin(Customize,ModelAdmin):
#     pass
admin.site.register(Customize)

# Register your models here.

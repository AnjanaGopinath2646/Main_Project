from django import forms
from django.contrib.auth.models import User
from . import models
from .models import Customize
from django.core.exceptions import ValidationError


class CustomizeForm(forms.ModelForm):
    class Meta:
        model = Customize
        fields = ['name', 'details']

# def minimum_length_validator(value):
#     """Custom validator to ensure password length is at least 8 characters."""
#     if len(value) < 8:
#         raise ValidationError("Password must be at least 8 characters long.")

# class CustomerUserForm(forms.ModelForm):
#     class Meta:
#         model = User
#         fields = ['first_name', 'last_name', 'username', 'password']
#         required_fields = '__all__'
#         widgets = {
#             'password': forms.PasswordInput(),
#         }

#     def clean_password(self):
#         """Custom method to validate password strength."""
#         password = self.cleaned_data['password']
#         # Check for minimum length using the custom validator
#         minimum_length_validator(password)

#         # Check for presence of at least one number and one symbol
#         if not any(char.isdigit() for char in password) or not any(not char.isalnum() for char in password):
#             raise ValidationError("Password must contain at least one number and one symbol.")

#         return password  # Return the validated password

# class CustomerForm(forms.ModelForm):
#     class Meta:
#         model = models.Customer  # Assuming Customer model exists
#         fields = ['address', 'mobile', 'profile_pic']
#         required_fields = '__all__'
class CustomerUserForm(forms.ModelForm):
    class Meta:
        model=User
        fields=['first_name','last_name','username','password']
        widgets = {
        'password': forms.PasswordInput()
        }
        
class CustomerForm(forms.ModelForm):
    class Meta:
        model=models.Customer
        fields=['address','mobile','profile_pic']

class CarpenterForm(forms.ModelForm):
    class Meta:
        model=models.Carpenter
        fields=['username','name','phone','address']


class ProductForm(forms.ModelForm):
    class Meta:
        model=models.Product
        fields=['name','price','description','product_image']

#address of shipment
class AddressForm(forms.Form):
    Email = forms.EmailField()
    Mobile= forms.IntegerField()
    Address = forms.CharField(max_length=500)

class FeedbackForm(forms.ModelForm):
    class Meta:
        model=models.Feedback
        fields=['name','feedback']

#for updating status of order
class OrderForm(forms.ModelForm):
    class Meta:
        model=models.Orders
        fields=['status']

#for contact us page
class ContactusForm(forms.Form):
    Name = forms.CharField(max_length=30)
    Email = forms.EmailField()
    Message = forms.CharField(max_length=500,widget=forms.Textarea(attrs={'rows': 3, 'cols': 30}))

class CustamizeForm(forms.ModelForm):
    class Meta:
        model=models.Customize
        fields=['status']
